# XML-RPC Settings

Secure your website with the most comprehensive XML-RPC Settings plugin.

![](wordpress.png)
